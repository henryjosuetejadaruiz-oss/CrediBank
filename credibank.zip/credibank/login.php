<?php
// ================================================
// CREDI BANK - Login
// VULNERABILIDADES INTENCIONALES (Académico ULS):
//   [1] Brute Force: Sin límite de intentos
//   [2] User Enumeration: Mensajes de error distintos
//   [3] Sin CAPTCHA
//   [4] Contraseñas débiles: admin/admin, user/1234
//   [5] Sin bloqueo de cuenta
// ================================================

require_once 'includes/db.php';

$error = "";
$success = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';

    // ⚠️ VULNEABLE: Consulta sin prepared statements + user enumeration
    $sql = "SELECT * FROM usuarios WHERE username = '$username' AND password = '$password'";
$result = mysqli_query($conn, $sql);
$user = mysqli_fetch_assoc($result);

if (!$user) {
    $error = "❌ Credenciales incorrectas.";

    } else {
        // Login exitoso - ⚠️ SIN regenerar session ID (Session Fixation)
        $_SESSION['user_id']  = $user['id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['nombre']   = $user['nombre'];
        $_SESSION['rol']      = $user['rol'];
        // ⚠️ VULNERABLE: Cookie sin HttpOnly ni Secure se configura en php.ini/htaccess
        header("Location: dashboard.php");
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Credi Bank - Iniciar Sesión</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="login-wrapper">
    <div class="login-box">
        <div class="login-logo">
            <h1>💳 Credi<span>Bank</span></h1>
            <p>Portal Bancario Personal</p>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-danger"><?= $error ?></div>
        <?php endif; ?>
        <?php if ($success): ?>
            <div class="alert alert-success"><?= $success ?></div>
        <?php endif; ?>

        <!-- ⚠️ Sin token CSRF -->
        <form method="POST" action="login.php" autocomplete="off">
            <div class="form-group">
                <label>👤 Usuario</label>
                <input type="text" name="username" placeholder="Ingresa tu usuario"
                       value="<?= htmlspecialchars($_POST['username'] ?? '') ?>" required>
            </div>
            <div class="form-group">
                <label>🔒 Contraseña</label>
                <input type="password" name="password" placeholder="Ingresa tu contraseña" required>
            </div>
            <!-- ⚠️ Sin CAPTCHA -->
            <button type="submit" class="btn btn-primary" style="width:100%;padding:12px;font-size:1rem;">
                Iniciar Sesión
            </button>
        </form>


    </div>
</div>
</body>
</html>
