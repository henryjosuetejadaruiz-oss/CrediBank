<?php
require_once 'includes/db.php';
 
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}
 
$uid = $_SESSION['user_id'];
$msg = "";
$tipo_msg = "";
 
$upload_dir = "uploads/";
if (!is_dir($upload_dir)) {
    mkdir($upload_dir, 0777, true);
}
 
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['archivo'])) {
    $archivo = $_FILES['archivo'];
    $nombre_original = $archivo['name'];
    $ruta_destino = $upload_dir . $nombre_original;
 
    if (move_uploaded_file($archivo['tmp_name'], $ruta_destino)) {
        mysqli_query($conn,
            "INSERT INTO documentos (usuario_id, nombre_archivo, ruta)
             VALUES ($uid, '$nombre_original', '$ruta_destino')"
        );
        $msg = "✅ Archivo subido: <strong>$nombre_original</strong>";
        $tipo_msg = "success";
    } else {
        $msg = "❌ Error al subir el archivo.";
        $tipo_msg = "danger";
    }
}
 
$res = mysqli_query($conn, "SELECT * FROM documentos WHERE usuario_id = $uid ORDER BY fecha_subida DESC");
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Documentos - Credi Bank</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
 
<?php include 'includes/navbar.php'; ?>
 
<div class="container">
    <div class="layout">
        <?php include 'includes/sidebar.php'; ?>
        <div class="main-content">
 
            <h2 class="page-title">📂 Documentos</h2>
 
            <?php if ($msg): ?>
                <div class="alert alert-<?= $tipo_msg ?>"><?= $msg ?></div>
            <?php endif; ?>
 
            <div class="card">
                <h3>⬆️ Subir Documento</h3>
                <form method="POST" enctype="multipart/form-data">
                    <div class="form-group">
                        <label>Selecciona el archivo</label>
                        <input type="file" name="archivo" style="padding:8px;">
                        <small style="color:#888;">Se aceptan: PDF, imágenes y otros formatos</small>
                    </div>
                    <button type="submit" class="btn btn-primary">⬆️ Subir Archivo</button>
                </form>
            </div>
 
            <div class="card">
                <h3>📋 Mis Documentos</h3>
                <?php if ($res && mysqli_num_rows($res) > 0): ?>
                <table>
                    <thead>
                        <tr><th>Archivo</th><th>Fecha</th><th>Acción</th></tr>
                    </thead>
                    <tbody>
                    <?php while ($d = mysqli_fetch_assoc($res)): ?>
                        <tr>
                            <td><?= htmlspecialchars($d['nombre_archivo']) ?></td>
                            <td><?= date('d/m/Y H:i', strtotime($d['fecha_subida'])) ?></td>
                            <td><a href="<?= $d['ruta'] ?>" target="_blank" class="btn btn-primary" style="padding:4px 10px;font-size:0.8rem;">Abrir</a></td>
                        </tr>
                    <?php endwhile; ?>
                    </tbody>
                </table>
                <?php else: ?>
                    <p style="color:#999;text-align:center;padding:20px;">No has subido documentos aún.</p>
                <?php endif; ?>
            </div>
 
        </div>
    </div>
</div>
 
</body>
</html>