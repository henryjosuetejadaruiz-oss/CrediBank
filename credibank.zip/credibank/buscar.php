<?php
// ================================================
// CREDI BANK - Búsqueda de Cuentas
// VULNERABILIDADES INTENCIONALES (Académico ULS):
//   [1] SQL Injection Clásica: input directo en consulta
//   [2] SQL Injection Blind: respuestas distintas por condición
//   [3] UNION SELECT permite extraer tablas y columnas
//   [4] Datos sensibles sin cifrar expuestos
//
// Payloads de prueba con Burp Suite:
//   ' OR '1'='1         → devuelve todos los registros
//   ' UNION SELECT 1,username,password,4,5,6,7,8 FROM usuarios-- -
//   ' AND 1=2 UNION SELECT ...   → Blind SQLi
// ================================================

require_once 'includes/db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$resultados = [];
$busqueda   = "";
$error_sql  = "";

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['q']) && $_GET['q'] !== '') {
    $busqueda = $_GET['q'];  // ⚠️ SIN sanitizar

    // ⚠️ VULNERABLE: SQL Injection directa
    $sql = "SELECT c.numero_cuenta, u.nombre, u.email, c.saldo, c.tipo, c.fecha_apertura
            FROM cuentas c
            JOIN usuarios u ON c.usuario_id = u.id
            WHERE c.numero_cuenta LIKE '%$busqueda%'
               OR u.nombre LIKE '%$busqueda%'";

    $res = mysqli_query($conn, $sql);

    if ($res === false) {
        // ⚠️ VULNERABLE: Muestra el error SQL completo al usuario
        $error_sql = "Error SQL: " . mysqli_error($conn);
    } else {
        while ($row = mysqli_fetch_assoc($res)) {
            $resultados[] = $row;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Buscar Cuenta - Credi Bank</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<?php include 'includes/navbar.php'; ?>

<div class="container">
    <div class="layout">
        <?php include 'includes/sidebar.php'; ?>
        <div class="main-content">

            <h2 class="page-title">🔍 Búsqueda de Cuentas
        
            </h2>

            <div class="card">
                <h3>Buscar por número de cuenta o nombre del titular</h3>
                <!-- ⚠️ Sin token CSRF, sin validación de input -->
                <form method="GET" action="buscar.php">
                    <div style="display:flex;gap:10px;">
                        <div class="form-group" style="flex:1;margin:0;">
                            <input type="text" name="q"
                                   value="<?= htmlspecialchars($busqueda) ?>"
                                   placeholder="Ej: 1001000002 o María García"
                                   style="height:44px;">
                        </div>
                        <button type="submit" class="btn btn-primary" style="height:44px;">
                            Buscar
                        </button>
                    </div>
                </form>

                <!-- Hint educativo -->
                
            </div>

            <?php if ($error_sql): ?>
                <div class="alert alert-danger">
                    <strong>⚠️ Error de Base de Datos (expuesto intencionalmente):</strong><br>
                    <code><?= $error_sql ?></code>
                </div>
            <?php endif; ?>

            <?php if (!empty($resultados)): ?>
            <div class="card">
                <h3>📋 Resultados (<?= count($resultados) ?> encontrados)</h3>
                <table>
                    <thead>
                        <tr>
                            <th>N° Cuenta</th>
                            <th>Titular</th>
                            <th>Email</th>
                            <th>Saldo</th>
                            <th>Tipo</th>
                            <th>Apertura</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($resultados as $r): ?>
                        <tr>
                            <td><strong><?= $r['numero_cuenta'] ?></strong></td>
                            <td><?= $r['nombre'] ?></td>
                            <td><?= $r['email'] ?></td>
                            <!-- ⚠️ Saldo mostrado sin cifrar -->
                            <td style="font-weight:700;color:#1a237e;">$<?= number_format($r['saldo'], 2) ?></td>
                            <td><?= $r['tipo'] ?></td>
                            <td><?= date('d/m/Y', strtotime($r['fecha_apertura'])) ?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php elseif ($busqueda !== ''): ?>
                <div class="alert alert-info">No se encontraron cuentas para: <strong><?= htmlspecialchars($busqueda) ?></strong></div>
            <?php endif; ?>

        </div>
    </div>
</div>

</body>
</html>
