<?php
// ================================================
// CREDI BANK - Transferencias
// VULNERABILIDADES INTENCIONALES (Académico ULS):
//   [1] CSRF: Sin token de validación en el formulario
//   [2] IDOR: Número de cuenta en URL es predecible (?cuenta=1001)
//   [3] Sin validación de monto en servidor
//   [4] Sin 2FA ni confirmación de operación
//   [5] Acceso directo a cuentas ajenas por IDOR
//
// Prueba CSRF en Burp Suite:
//   Interceptar POST y reproducir desde otro origen
// IDOR: Cambiar ?cuenta=1001000001 a otro número
// ================================================

require_once 'includes/db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$uid = $_SESSION['user_id'];
$msg = "";
$tipo_msg = "";

// ⚠️ IDOR: Cuenta obtenida del parámetro GET sin verificar pertenencia
$cuenta_id = $_GET['cuenta'] ?? null;

if ($cuenta_id) {
    // ⚠️ VULNERABLE IDOR: Busca cualquier cuenta sin verificar que sea del usuario
    $res_cuenta = mysqli_query($conn,
        "SELECT c.*, u.nombre FROM cuentas c JOIN usuarios u ON c.usuario_id = u.id
         WHERE c.numero_cuenta = '$cuenta_id'"
    );
    $cuenta = mysqli_fetch_assoc($res_cuenta);
} else {
    $res_cuenta = mysqli_query($conn,
        "SELECT c.*, u.nombre FROM cuentas c JOIN usuarios u ON c.usuario_id = u.id
         WHERE c.usuario_id = $uid LIMIT 1"
    );
    $cuenta = mysqli_fetch_assoc($res_cuenta);
}

// Procesar transferencia
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $origen  = $_POST['cuenta_origen']  ?? '';
    $destino = $_POST['cuenta_destino'] ?? '';
    $monto   = $_POST['monto']          ?? 0;
    $concepto = $_POST['concepto']      ?? '';

    // ⚠️ VULNERABLE: Sin validación de que origen pertenece al usuario
    // ⚠️ VULNERABLE: Sin token CSRF
    // ⚠️ VULNERABLE: Sin validación de monto negativo

    $res_origen = mysqli_query($conn, "SELECT * FROM cuentas WHERE numero_cuenta = '$origen'");
    $c_origen   = mysqli_fetch_assoc($res_origen);
    $res_destino = mysqli_query($conn, "SELECT * FROM cuentas WHERE numero_cuenta = '$destino'");
    $c_destino   = mysqli_fetch_assoc($res_destino);

    if (!$c_origen) {
        $msg = "❌ Cuenta de origen no encontrada."; $tipo_msg = "danger";
    } elseif (!$c_destino) {
        $msg = "❌ Cuenta de destino no encontrada."; $tipo_msg = "danger";
    } elseif ($monto <= 0) {
        $msg = "❌ El monto debe ser positivo."; $tipo_msg = "danger";
    } else {
        // Ejecutar transferencia sin verificación de saldo suficiente
        mysqli_query($conn, "UPDATE cuentas SET saldo = saldo - $monto WHERE numero_cuenta = '$origen'");
        mysqli_query($conn, "UPDATE cuentas SET saldo = saldo + $monto WHERE numero_cuenta = '$destino'");
        mysqli_query($conn,
            "INSERT INTO transferencias (cuenta_origen, cuenta_destino, monto, concepto, usuario_id)
             VALUES ('$origen', '$destino', $monto, '$concepto', $uid)"
        );
        $msg = "✅ Transferencia de \$$monto realizada correctamente."; $tipo_msg = "success";

        // Recargar cuenta
        $res_cuenta = mysqli_query($conn,
            "SELECT c.*, u.nombre FROM cuentas c JOIN usuarios u ON c.usuario_id = u.id
             WHERE c.usuario_id = $uid LIMIT 1"
        );
        $cuenta = mysqli_fetch_assoc($res_cuenta);
    }
}

// Todas las cuentas del sistema (para el selector destino)
$res_cuentas = mysqli_query($conn,
    "SELECT c.numero_cuenta, u.nombre FROM cuentas c JOIN usuarios u ON c.usuario_id = u.id"
);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Transferencias - Credi Bank</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<?php include 'includes/navbar.php'; ?>

<div class="container">
    <div class="layout">
        <?php include 'includes/sidebar.php'; ?>
        <div class="main-content">

            <h2 class="page-title">💸 Transferencias
            
            </h2>

            <?php if ($msg): ?>
                <div class="alert alert-<?= $tipo_msg ?>"><?= $msg ?></div>
            <?php endif; ?>

            <!-- IDOR Demo: cambiar número de cuenta en URL -->
        

            <?php if ($cuenta): ?>
            <div class="stat-card" style="margin-bottom:20px;">
                <div style="font-size:2rem;">💳</div>
                <div class="amount">$<?= number_format($cuenta['saldo'], 2) ?></div>
                <div class="label">Cuenta: <?= $cuenta['numero_cuenta'] ?> | Titular: <?= $cuenta['nombre'] ?></div>
            </div>
            <?php endif; ?>

            <div class="card">
                <h3>Nueva Transferencia</h3>
                <!-- ⚠️ CSRF: Sin token de validación -->
                <form method="POST">
                    <div class="form-group">
                        <label>Cuenta Origen</label>
                        <input type="text" name="cuenta_origen"
                               value="<?= $cuenta['numero_cuenta'] ?? '' ?>"
                               placeholder="Número de cuenta origen">
                    </div>
                    <div class="form-group">
                        <label>Cuenta Destino</label>
                        <select name="cuenta_destino">
                            <option value="">-- Selecciona cuenta destino --</option>
                            <?php while ($c = mysqli_fetch_assoc($res_cuentas)): ?>
                                <option value="<?= $c['numero_cuenta'] ?>">
                                    <?= $c['numero_cuenta'] ?> — <?= $c['nombre'] ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    <div class="grid-2">
                        <div class="form-group">
                            <label>Monto ($)</label>
                            <!-- ⚠️ Sin validación de monto máximo en servidor -->
                            <input type="number" name="monto" placeholder="0.00" step="0.01" min="0">
                        </div>
                        <div class="form-group">
                            <label>Concepto</label>
                            <input type="text" name="concepto" placeholder="Descripción opcional">
                        </div>
                    </div>
                    <!-- ⚠️ Sin paso de confirmación ni 2FA -->
                    <button type="submit" class="btn btn-primary">💸 Transferir Ahora</button>
                </form>
            </div>

            <!-- IDOR: Links directos a otras cuentas -->
            <div class="card">
                <h3>📋 Acceso IDOR a otras cuentas (demo educativo)</h3>
                <div style="display:flex;gap:10px;flex-wrap:wrap;">
                    <?php
                    $res_all = mysqli_query($conn, "SELECT c.numero_cuenta, u.nombre FROM cuentas c JOIN usuarios u ON c.usuario_id = u.id");
                    while ($c = mysqli_fetch_assoc($res_all)):
                    ?>
                    <a href="transferencias.php?cuenta=<?= $c['numero_cuenta'] ?>" class="btn btn-primary" style="font-size:0.8rem;padding:6px 12px;">
                        <?= $c['numero_cuenta'] ?> (<?= $c['nombre'] ?>)
                    </a>
                    <?php endwhile; ?>
                </div>
            </div>

        </div>
    </div>
</div>

</body>
</html>
