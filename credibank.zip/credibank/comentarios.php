<?php
// ================================================
// CREDI BANK - Comentarios
// VULNERABILIDADES INTENCIONALES (Académico ULS):
//   [1] XSS Almacenado: comentarios guardados sin sanitizar
//   [2] Se muestran a todos los usuarios (persistente)
//   [3] Puede robar cookies de sesión de otros usuarios
//   [4] Sin límite de longitud ni validación de input
// ================================================

require_once 'includes/db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$uid = $_SESSION['user_id'];
$msg = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $comentario = $_POST['comentario'] ?? '';

    // ⚠️ VULNERABLE: XSS Almacenado - sin sanitización antes de guardar
    $sql = "INSERT INTO comentarios (usuario_id, comentario) VALUES ($uid, '$comentario')";
    if (mysqli_query($conn, $sql)) {
        $msg = "success";
    }
}

// Obtener todos los comentarios
$res = mysqli_query($conn,
    "SELECT c.*, u.nombre FROM comentarios c
     JOIN usuarios u ON c.usuario_id = u.id
     ORDER BY c.fecha DESC"
);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Comentarios - Credi Bank</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<?php include 'includes/navbar.php'; ?>

<div class="container">
    <div class="layout">
        <?php include 'includes/sidebar.php'; ?>
        <div class="main-content">

            <h2 class="page-title">💬 Comentarios y Soporte
            </h2>

            <?php if ($msg === 'success'): ?>
                <div class="alert alert-success">✅ Comentario publicado.</div>
            <?php endif; ?>

            <div class="card">
                <h3>✍️ Nuevo Comentario</h3>
                <form method="POST">
                    <div class="form-group">
                        <label>Escribe tu comentario o consulta</label>
                        <!-- ⚠️ Sin sanitización ni validación -->
                        <textarea name="comentario" rows="4"></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary">💬 Publicar</button>
                </form>
            </div>

            <div class="card">
                <h3>📋 Comentarios de Usuarios</h3>
                <?php if (mysqli_num_rows($res) > 0): ?>
                <?php while ($c = mysqli_fetch_assoc($res)): ?>
                <div style="border-bottom:1px solid #eee;padding:14px 0;">
                    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;">
                        <strong style="color:#1a237e;">👤 <?= htmlspecialchars($c['nombre']) ?></strong>
                        <span style="color:#999;font-size:0.82rem;"><?= date('d/m/Y H:i', strtotime($c['fecha'])) ?></span>
                    </div>
                    <!-- ⚠️ VULNERABLE: XSS Almacenado - comentario se imprime SIN escapar -->
                    <div><?= $c['comentario'] /* ⚠️ Sin htmlspecialchars() */ ?></div>
                </div>
                <?php endwhile; ?>
                <?php else: ?>
                    <p style="color:#999;text-align:center;padding:20px;">Sin comentarios aún.</p>
                <?php endif; ?>
            </div>

        </div>
    </div>
</div>

</body>
</html>
