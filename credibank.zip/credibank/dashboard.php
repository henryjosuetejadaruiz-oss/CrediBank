<?php
// ================================================
// CREDI BANK - Dashboard
// ================================================
require_once 'includes/db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$uid = $_SESSION['user_id'];

// Obtener cuenta del usuario
$res = mysqli_query($conn, "SELECT * FROM cuentas WHERE usuario_id = $uid LIMIT 1");
$cuenta = mysqli_fetch_assoc($res);

// Últimas 5 transferencias
$res2 = mysqli_query($conn,
    "SELECT t.*, u.nombre FROM transferencias t
     LEFT JOIN usuarios u ON t.usuario_id = u.id
     WHERE t.cuenta_origen = '{$cuenta['numero_cuenta']}'
        OR t.cuenta_destino = '{$cuenta['numero_cuenta']}'
     ORDER BY t.fecha DESC LIMIT 5"
);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Dashboard - Credi Bank</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<?php include 'includes/navbar.php'; ?>

<div class="container">
    <div class="layout">
        <?php include 'includes/sidebar.php'; ?>
        <div class="main-content">

            <h2 class="page-title">📊 Mi Dashboard</h2>

            <div class="grid-3">
                <div class="stat-card">
                    <div style="font-size:2rem;">💰</div>
                    <div class="amount">$<?= number_format($cuenta['saldo'], 2) ?></div>
                    <div class="label">Saldo Disponible</div>
                </div>
                <div class="stat-card green">
                    <div style="font-size:2rem;">🏦</div>
                    <div class="amount" style="font-size:1.2rem;"><?= $cuenta['numero_cuenta'] ?></div>
                    <div class="label">Número de Cuenta</div>
                </div>
                <div class="stat-card yellow">
                    <div style="font-size:2rem;">📋</div>
                    <div class="amount" style="font-size:1.3rem;text-transform:capitalize;"><?= $cuenta['tipo'] ?></div>
                    <div class="label">Tipo de Cuenta</div>
                </div>
            </div>

            <div class="card">
                <h3>📜 Últimos Movimientos</h3>
                <?php if (mysqli_num_rows($res2) > 0): ?>
                <table>
                    <thead>
                        <tr>
                            <th>Fecha</th>
                            <th>Origen</th>
                            <th>Destino</th>
                            <th>Concepto</th>
                            <th>Monto</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php while ($t = mysqli_fetch_assoc($res2)): ?>
                        <tr>
                            <td><?= date('d/m/Y H:i', strtotime($t['fecha'])) ?></td>
                            <td><?= $t['cuenta_origen'] ?></td>
                            <td><?= $t['cuenta_destino'] ?></td>
                            <td><?= htmlspecialchars($t['concepto']) ?></td>
                            <td style="font-weight:700;color:<?= ($t['cuenta_origen'] == $cuenta['numero_cuenta']) ? '#c62828' : '#2e7d32' ?>">
                                <?= ($t['cuenta_origen'] == $cuenta['numero_cuenta']) ? '-' : '+' ?>
                                $<?= number_format($t['monto'], 2) ?>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                    </tbody>
                </table>
                <?php else: ?>
                    <p style="color:#999;text-align:center;padding:20px;">Sin movimientos registrados.</p>
                <?php endif; ?>
            </div>

            <div class="alert alert-info">
                👋 Bienvenido, <strong><?= $_SESSION['nombre'] ?></strong>.
                Sesión iniciada como <strong><?= $_SESSION['rol'] ?></strong>.
            </div>

        </div>
    </div>
</div>

</body>
</html>
