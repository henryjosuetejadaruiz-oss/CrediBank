-- ================================================
-- CREDI BANK - Base de Datos
-- Proyecto Académico - Seguridad Informática ULS
-- ================================================

CREATE DATABASE IF NOT EXISTS credibank;
USE credibank;

-- Tabla de usuarios
CREATE TABLE usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(100) NOT NULL,
    nombre VARCHAR(100) NOT NULL,
    email VARCHAR(100),
    telefono VARCHAR(20),
    direccion VARCHAR(200),
    rol ENUM('admin','user') DEFAULT 'user',
    activo TINYINT(1) DEFAULT 1,
    fecha_creacion DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Tabla de cuentas bancarias
CREATE TABLE cuentas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    numero_cuenta VARCHAR(20) NOT NULL UNIQUE,
    usuario_id INT NOT NULL,
    saldo DECIMAL(12,2) DEFAULT 0.00,
    tipo ENUM('ahorro','corriente') DEFAULT 'ahorro',
    fecha_apertura DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
);

-- Tabla de transferencias
CREATE TABLE transferencias (
    id INT AUTO_INCREMENT PRIMARY KEY,
    cuenta_origen VARCHAR(20) NOT NULL,
    cuenta_destino VARCHAR(20) NOT NULL,
    monto DECIMAL(12,2) NOT NULL,
    concepto VARCHAR(200),
    fecha DATETIME DEFAULT CURRENT_TIMESTAMP,
    usuario_id INT
);

-- Tabla de comentarios (para XSS almacenado)
CREATE TABLE comentarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT,
    comentario TEXT NOT NULL,
    fecha DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Tabla de documentos subidos
CREATE TABLE documentos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT,
    nombre_archivo VARCHAR(200),
    ruta VARCHAR(300),
    fecha_subida DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- ================================================
-- DATOS DE PRUEBA (contraseñas débiles intencionales)
-- ================================================

INSERT INTO usuarios (username, password, nombre, email, telefono, direccion, rol) VALUES
('admin',    '12345678',   'Henrry Tejada', 'admin@credibank.com',    '2222-0000', 'San Salvador, El Salvador', 'admin'),
('maria',    '123456',    'María Díaz',         'maria@gmail.com',        '7890-1234', 'San Salvador, El Salvador',   'user'),
('rodolfo',   '123456',  'Rodolfo Vigil',     'rodolfo@gmail.com',     '7654-3210', 'San Miguel, El Salvador',  'user'),

INSERT INTO cuentas (numero_cuenta, usuario_id, saldo, tipo) VALUES
('1001000001', 1, 10000.00, 'corriente'),
('1001000002', 2, 8500.75,   'ahorro'),
('1001000003', 3, 5550.00,  'corriente'),


INSERT INTO transferencias (cuenta_origen, cuenta_destino, monto, concepto, usuario_id) VALUES
('1001000002', '1001000003', 500.00,  'Pago de alquiler',   2),
('1001000003', '1001000004', 1200.00, 'Compra de muebles',  1),
('1001000005', '1001000002', 300.00,  'Préstamo personal',  3);

INSERT INTO comentarios (usuario_id, comentario) VALUES
(2, 'Excelente servicio del banco, muy rápido.'),
(3, 'Tuve un problema con mi transferencia pero lo resolvieron.'),
(3, 'Me gustaría que agregaran más cajeros automáticos.');
