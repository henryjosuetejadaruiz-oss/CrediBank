<?php
require_once 'includes/db.php';
// ⚠️ VULNERABLE: No regenera session ID al logout (Session Fixation)
session_destroy();
header("Location: login.php");
exit;
?>
