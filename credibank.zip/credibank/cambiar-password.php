<?php
require_once 'includes/db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$uid = $_SESSION['user_id'];
$msg = "";
$tipo_msg = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $password_actual   = $_POST['password_actual']   ?? '';
    $password_nueva    = $_POST['password_nueva']    ?? '';
    $password_confirmar = $_POST['password_confirmar'] ?? '';

    // Obtener contraseña actual del usuario
    $res  = mysqli_query($conn, "SELECT password FROM usuarios WHERE id = $uid");
    $user = mysqli_fetch_assoc($res);

    if ($password_actual !== $user['password']) {
        $msg = "❌ La contraseña actual es incorrecta.";
        $tipo_msg = "danger";
    } elseif (strlen($password_nueva) < 4) {
        $msg = "❌ La nueva contraseña debe tener al menos 4 caracteres.";
        $tipo_msg = "danger";
    } elseif ($password_nueva !== $password_confirmar) {
        $msg = "❌ Las contraseñas nuevas no coinciden.";
        $tipo_msg = "danger";
    } else {
        // Actualizar contraseña sin hashear (vulnerable intencional)
        mysqli_query($conn, "UPDATE usuarios SET password = '$password_nueva' WHERE id = $uid");
        $msg = "✅ Contraseña actualizada correctamente.";
        $tipo_msg = "success";
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Cambiar Contraseña - Credi Bank</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<?php include 'includes/navbar.php'; ?>

<div class="container">
    <div class="layout">
        <?php include 'includes/sidebar.php'; ?>
        <div class="main-content">

            <h2 class="page-title">🔑 Cambiar Contraseña</h2>

            <?php if ($msg): ?>
                <div class="alert alert-<?= $tipo_msg ?>"><?= $msg ?></div>
            <?php endif; ?>

            <div class="card">
                <h3>Actualiza tu contraseña de acceso</h3>
                <form method="POST" style="max-width:500px;">
                    <div class="form-group">
                        <label>🔒 Contraseña Actual</label>
                        <input type="password" name="password_actual"
                               placeholder="Ingresa tu contraseña actual" required>
                    </div>
                    <div class="form-group">
                        <label>🆕 Nueva Contraseña</label>
                        <input type="password" name="password_nueva"
                               placeholder="Ingresa tu nueva contraseña" required>
                    </div>
                    <div class="form-group">
                        <label>✅ Confirmar Nueva Contraseña</label>
                        <input type="password" name="password_confirmar"
                               placeholder="Repite tu nueva contraseña" required>
                    </div>
                    <button type="submit" class="btn btn-primary">🔑 Cambiar Contraseña</button>
                </form>
            </div>

            <div class="card" style="background:#f8f9ff;">
                <h3>💡 Recomendaciones de seguridad</h3>
                <ul style="padding-left:20px;line-height:2;">
                    <li>Usa al menos 8 caracteres</li>
                    <li>Combina letras, números y símbolos</li>
                    <li>No uses tu nombre o fecha de nacimiento</li>
                    <li>No compartas tu contraseña con nadie</li>
                    <li>Cambia tu contraseña regularmente</li>
                </ul>
            </div>

        </div>
    </div>
</div>

</body>
</html>
