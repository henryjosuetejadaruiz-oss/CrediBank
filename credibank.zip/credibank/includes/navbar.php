<?php
$base = (strpos($_SERVER['PHP_SELF'], '/admin/') !== false) ? '../' : '';
?>
<div class="navbar">
    <a href="<?= $base ?>dashboard.php" class="logo">
        <div class="logo-text">💳 Credi<span>Bank</span></div>
    </a>
    <nav>
        <a href="<?= $base ?>logout.php" class="btn-logout">Salir</a>
    </nav>
</div>