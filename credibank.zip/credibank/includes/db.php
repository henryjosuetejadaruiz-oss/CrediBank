<?php
// ================================================
// CREDI BANK - Conexión a Base de Datos
// VULNERABLE INTENCIONAL - Proyecto Académico ULS
// ================================================

$host = "localhost";
$dbname = "credibank";
$user = "root";
$pass = "";  // XAMPP por defecto no tiene contraseña

// Conexión con mysqli (sin PDO para permitir SQLi)
$conn = mysqli_connect($host, $user, $pass, $dbname);

if (!$conn) {
    die("Error de conexión: " . mysqli_connect_error());
}

mysqli_set_charset($conn, "utf8");

// Iniciar sesión si no está iniciada
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
?>
