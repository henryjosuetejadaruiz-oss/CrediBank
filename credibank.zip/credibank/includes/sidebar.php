<?php
$base = (strpos($_SERVER['PHP_SELF'], '/admin/') !== false) ? '../' : '';
$current = basename($_SERVER['PHP_SELF']);
?>
<div class="sidebar">
    <div class="sidebar-menu">
        <a href="<?= $base ?>dashboard.php" class="<?= $current=='dashboard.php'?'active':'' ?>">
            <span class="icon">🏠</span> Dashboard
        </a>
        <a href="<?= $base ?>transferencias.php" class="<?= $current=='transferencias.php'?'active':'' ?>">
            <span class="icon">💸</span> Transferencias
        </a>
        <a href="<?= $base ?>buscar.php" class="<?= $current=='buscar.php'?'active':'' ?>">
            <span class="icon">🔍</span> Buscar Cuenta
        </a>
        <a href="<?= $base ?>perfil.php" class="<?= $current=='perfil.php'?'active':'' ?>">
            <span class="icon">👤</span> Mi Perfil
        </a>
        <a href="<?= $base ?>cambiar-password.php" class="<?= $current=='cambiar-password.php'?'active':'' ?>">
    <span class="icon">🔑</span> Cambiar Contraseña
</a>
        <a href="<?= $base ?>documentos.php" class="<?= $current=='documentos.php'?'active':'' ?>">
            <span class="icon">📂</span> Documentos
        </a>
        <a href="<?= $base ?>comentarios.php" class="<?= $current=='comentarios.php'?'active':'' ?>">
            <span class="icon">💬</span> Comentarios
        </a>
        <?php if (isset($_SESSION['rol']) && $_SESSION['rol'] === 'admin'): ?>
        <a href="<?= $base ?>admin/dashboard.php" class="<?= $current=='admin_dashboard.php'?'active':'' ?>">
            <span class="icon">⚙️</span> Panel Admin
        </a>
        <?php endif; ?>
    </div>

</div>
