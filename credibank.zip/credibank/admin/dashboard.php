<?php
// ================================================
// CREDI BANK - Panel de Administración
// VULNERABILIDADES INTENCIONALES (Académico ULS):
//   [1] Broken Access Control: Solo verifica login, NO el rol
//   [2] Directorio listable (configurar en Apache: Options +Indexes)
//   [3] Muestra todos los saldos y datos de usuarios
//   [4] Funciones destructivas sin confirmación
//   [5] Accesible en /admin/dashboard.php para cualquier usuario
// ================================================

require_once '../includes/db.php';

// ⚠️ VULNERABLE: Solo verifica si hay sesión activa, NO verifica rol 'admin'
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit;
}
// ⚠️ Línea correcta (comentada) - si se aplicara:
// if (!isset($_SESSION['rol']) || $_SESSION['rol'] !== 'admin') { header("Location: ../dashboard.php"); exit; }

$msg = "";
$tipo_msg = "";

// Eliminar usuario
if (isset($_GET['eliminar'])) {
    $id_eliminar = intval($_GET['eliminar']);
    mysqli_query($conn, "DELETE FROM cuentas WHERE usuario_id = $id_eliminar");
    mysqli_query($conn, "DELETE FROM usuarios WHERE id = $id_eliminar");
    $msg = "✅ Usuario eliminado."; $tipo_msg = "success";
}

// Todos los usuarios con saldos
$res_users = mysqli_query($conn,
    "SELECT u.*, c.numero_cuenta, c.saldo, c.tipo
     FROM usuarios u
     LEFT JOIN cuentas c ON c.usuario_id = u.id
     ORDER BY u.id"
);

// Estadísticas
$total_saldo   = mysqli_fetch_assoc(mysqli_query($conn, "SELECT SUM(saldo) as total FROM cuentas"))['total'];
$total_users   = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as cnt FROM usuarios"))['cnt'];
$total_transf  = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as cnt FROM transferencias"))['cnt'];
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Panel Admin - Credi Bank</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>

<?php include '../includes/navbar.php'; ?>

<div class="container">
    <div class="layout">
        <?php include '../includes/sidebar.php'; ?>
        <div class="main-content">

            <h2 class="page-title">⚙️ Panel de Administración
    
            </h2>

            <?php if ($msg): ?>
                <div class="alert alert-<?= $tipo_msg ?>"><?= $msg ?></div>
            <?php endif; ?>

            <div class="grid-3" style="margin-bottom:24px;">
                <div class="stat-card">
                    <div style="font-size:2rem;">👥</div>
                    <div class="amount"><?= $total_users ?></div>
                    <div class="label">Usuarios Totales</div>
                </div>
                <div class="stat-card green">
                    <div style="font-size:2rem;">💰</div>
                    <div class="amount">$<?= number_format($total_saldo, 2) ?></div>
                    <div class="label">Saldo Total Sistema</div>
                </div>
                <div class="stat-card yellow">
                    <div style="font-size:2rem;">📊</div>
                    <div class="amount"><?= $total_transf ?></div>
                    <div class="label">Transferencias</div>
                </div>
            </div>

            <div class="card" style="overflow-x: auto; padding: 20px;">
    <h3>👥 Gestión de Usuarios — Todos los datos expuestos</h3>
    <table style="min-width: 800px;">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Usuario</th>
                            <th>Contraseña ⚠️</th>
                            <th>Nombre</th>
                            <th>Email</th>
                            <th>Rol</th>
                            <th>N° Cuenta</th>
                            <th>Saldo</th>
                            <th>Acción</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php while ($u = mysqli_fetch_assoc($res_users)): ?>
                        <tr>
                            <td><?= $u['id'] ?></td>
                            <td><strong><?= $u['username'] ?></strong></td>
                            <!-- ⚠️ Contraseña en texto plano visible -->
                            <td><code style="color:#c62828;"><?= $u['password'] ?></code></td>
                            <td><?= $u['nombre'] ?></td>
                            <td><?= $u['email'] ?></td>
                            <td><?= $u['rol'] ?></td>
                            <td><?= $u['numero_cuenta'] ?></td>
                            <td style="font-weight:700;">$<?= number_format($u['saldo'], 2) ?></td>
                            <td>
                                <?php if ($u['id'] != 1): ?>
                                <!-- ⚠️ Sin confirmación ni token CSRF -->
                                <a href="?eliminar=<?= $u['id'] ?>"
                                   class="btn btn-danger"
                                   style="padding:4px 10px;font-size:0.78rem;"
                                   onclick="return confirm('¿Eliminar usuario?')">
                                    🗑️ Eliminar
                                </a>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                    </tbody>
                </table>
            </div>

            <div class="card">
                <h3>📂 Archivos del Servidor (Directory Listing)</h3>
                
                <div style="display:flex;gap:10px;flex-wrap:wrap;">
                    <a href="../uploads/" target="_blank" class="btn btn-primary">📁 /uploads/</a>
                    <a href="../" target="_blank" class="btn btn-primary">📁 /credibank/ (raíz)</a>
                    <a href="../includes/" target="_blank" class="btn btn-primary">📁 /includes/</a>
                </div>
            </div>

        </div>
    </div>
</div>

</body>
</html>
