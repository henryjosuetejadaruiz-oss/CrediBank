<?php
// Redirigir raíz al login
header("Location: login.php");
exit;
?>
